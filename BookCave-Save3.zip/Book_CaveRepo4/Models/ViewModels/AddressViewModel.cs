namespace BookCave.Models.ViewModels
{
    public class AddressViewModel
    {
        public int Id { get; set; }
        public string StreetLine { get; set; }
        public int PostalCode { get; set; }
        public string Country { get; set; }
    }
}