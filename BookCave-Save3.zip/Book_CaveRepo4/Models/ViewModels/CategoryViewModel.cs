using System;
using System.Collections.Generic;
using BookCave.Models.ViewModels;

namespace BookCave.Models.ViewModels
{
    public class CategoryViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        //public List<SubCategoryViewModel> SubCateGoryList { get; set; }
    }
}