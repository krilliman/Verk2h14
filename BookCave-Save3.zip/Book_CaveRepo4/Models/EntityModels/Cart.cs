namespace BookCave.Models.EntityModels
{
    public class Cart
    {
        public int Id { get; set; }
    }
}